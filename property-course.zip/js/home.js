// slide home
var swiper = new Swiper('.slide-head', {
  autoplay: {
    delay: 3500,
    disableOnInteraction: false,
  },
  pagination: {
    el: '.swiper-pagination',
  },
});